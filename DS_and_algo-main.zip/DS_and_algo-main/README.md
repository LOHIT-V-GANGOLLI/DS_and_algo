# Some codes on DSA 
**The language used is C programming language** 

 There exists a python script to clean your junk .exe files on windows 
 
*junk.py*
 
 run this script to clean all your compiled files

*coded during my 3rd semester in CSE*
