#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>

// program to find first n prime numbers using naive method



int main()
{
    /* code */
    return 0;
}